<?php


define("servername","localhost");
define("username","root");
define("password","");
define("dbname","lab_post");


//$con = mysqli_connect($servername,$username,$password,$dbname) or die ("could not connect database");

?>