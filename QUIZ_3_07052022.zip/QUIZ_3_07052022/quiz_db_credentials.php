<?php


define("servername","localhost");
define("username","root");
define("password","");
define("dbname","class_prac_db");


//$con = mysqli_connect($servername,$username,$password,$dbname) or die ("could not connect database");

?>